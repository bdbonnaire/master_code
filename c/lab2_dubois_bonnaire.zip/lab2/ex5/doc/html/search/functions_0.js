var searchData=
[
  ['add_0',['add',['../classPPoint.html#a21b69a6a589d366651de203cabe01067',1,'PPoint::add()'],['../classArray__of__PPoint.html#ace86a2d9a2699f44b3c74d429dd4652a',1,'Array_of_PPoint::add(const PPoint &amp;p)']]],
  ['array_5fof_5fppoint_1',['Array_of_PPoint',['../classArray__of__PPoint.html#a6550552a7581ed3d80fe7a2c85933077',1,'Array_of_PPoint::Array_of_PPoint(const unsigned int &amp;len)'],['../classArray__of__PPoint.html#ae196471e17097315758e97132cfd7561',1,'Array_of_PPoint::Array_of_PPoint(const unsigned int &amp;len, const unsigned int &amp;x0, const unsigned int &amp;x1, const unsigned int &amp;y0, const unsigned int &amp;y1)'],['../classArray__of__PPoint.html#acdf1c05042ae129f0e1017b9e5262bd9',1,'Array_of_PPoint::Array_of_PPoint(const Array_of_PPoint &amp;p)']]]
];
