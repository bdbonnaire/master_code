var searchData=
[
  ['ppoint_0',['PPoint',['../classPPoint.html',1,'PPoint'],['../classPPoint.html#a417b055945ccf3a5cc22e089ebaadb9e',1,'PPoint::PPoint(const int &amp;x=0, const int &amp;y=0)'],['../classPPoint.html#a9b262cdf9ea5b1befe64f2c087f331af',1,'PPoint::PPoint(const PPoint &amp;point)']]],
  ['ppoint_2ehpp_1',['PPoint.hpp',['../PPoint_8hpp.html',1,'']]],
  ['print_2',['print',['../classPPoint.html#a5044cbc28927b46c98219adbecea0f9e',1,'PPoint']]],
  ['print_5ftabs_3',['print_tabs',['../classArray__of__PPoint.html#a36793c409f640dfc14b1ac5416ccdfc4',1,'Array_of_PPoint']]]
];
