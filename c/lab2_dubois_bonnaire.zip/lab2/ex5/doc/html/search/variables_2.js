var searchData=
[
  ['x_0',['x',['../classPPoint.html#a50ba2cb0471d73e14f2c760e17e32a38',1,'PPoint']]]
];
