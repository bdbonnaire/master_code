var searchData=
[
  ['set_5fcoordinates_0',['set_coordinates',['../classPPoint.html#a9b69bb0acf619ea31976924c3064658e',1,'PPoint']]]
];
