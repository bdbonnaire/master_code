var searchData=
[
  ['ppoint_0',['PPoint',['../classPPoint.html#a417b055945ccf3a5cc22e089ebaadb9e',1,'PPoint::PPoint(const int &amp;x=0, const int &amp;y=0)'],['../classPPoint.html#a9b262cdf9ea5b1befe64f2c087f331af',1,'PPoint::PPoint(const PPoint &amp;point)']]],
  ['print_1',['print',['../classPPoint.html#a5044cbc28927b46c98219adbecea0f9e',1,'PPoint']]],
  ['print_5ftabs_2',['print_tabs',['../classArray__of__PPoint.html#a36793c409f640dfc14b1ac5416ccdfc4',1,'Array_of_PPoint']]]
];
